function start() {
    startGame();   
    
}