function start() {
    var catsParagraph = document.getElementById("cats");
    var catsText = catsParagraph.textContent;
}