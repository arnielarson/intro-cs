// Washington Huskies Stats - 2013-14
// Source: http://espn.go.com/mens-college-basketball/team/stats/_/id/264/washington-huskies
var players = [
    {
        name: "C.J. Wilcox",
        pointsPerGame: 22.0
    },
    {
        name: "Andrew Andrews",
        pointsPerGame: 21.0
    },
    {
        name: "Darin Johnson",
        pointsPerGame: 16.0
    },
    {
        name: "Mike Anderson",
        pointsPerGame: 12.0
    },
    {
        name: "Shawn Kemp, Jr.",
        pointsPerGame: 10.0
    },
    {
        name: "Nigel Williams-Goss",
        pointsPerGame: 6.0    
    },
    {
        name: "Jernard Jarreau",
        pointsPerGame: 1.0    
    },
    {
        name: "Hikeem Stewart",
        pointsPerGame: 0.0    
    },
    {
        name: "Gilles Dierickx",
        pointsPerGame: 0.0    
    }
];

function start() {
    
}