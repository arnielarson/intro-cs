function start() {
    var distance = {
        feet: 0,
        inches: 1
    };
    
    var longMeasurement = formatMeasurementLong(distance);
    var shortMeasurement = formatMeasurementShort(distance);
}

function formatMeasurementLong(distance) {
    
}

function formatMeasurementShort(distance) {
    
}