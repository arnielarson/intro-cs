// source: http://wiki.answers.com/Q/What_is_a_list_of_the_planets_according_to_size
var planets = [
    { 
        name: "Jupiter", 
        size: 143000 
    },
    { 
        name: "Saturn",
        size: 125000
    },
    { 
        name: "Uranus",
        size: 51100
    },
    { 
        name: "Neptune",
        size: 49500
    },
    {
        name: "Earth",
        size: 12800
    },
    {
        name: "Venus",
        size: 12100
    },
    { 
        name: "Mars",
        size: 6800
    },
    {
        name: "Mercury",
        size: 4900  
    }
];

function start() {

}