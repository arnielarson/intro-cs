// Kentucky Wildcats Stats: 2012-13, Season Statistics
// Source: http://espn.go.com/mens-college-basketball/team/stats/_/id/96/kentucky-wildcats
var players = [
    {
        name: "Archie Goodwin",
        minutes: 1048
    },
    {
        name: "Alex Poythress",
        minutes: 852
    },
    {
        name: "Nerlens Noel",
        minutes: 765
    },
    {
        name: "Kyle Wiltjer",
        minutes: 784
    },
    {
        name: "Ryan Harrow",
        minutes: 787
    },
    {
        name: "Julius Mays",
        minutes: 1090
    },
    {
        name: "Willie Cauley-Stein",
        minutes: 683
    },
    {
        name: "Jarrod Polson",
        minutes: 457
    },
    {
        name: "Jon Hood",
        minutes: 146
    },
    {
        name: "Twany Beckham",
        minutes: 17
    },
    {
        name: "Sam Malone",
        minutes: 6
    },
    {
        name: "Brian Long",
        minutes: 6
    },
    {
        name: "Tod Lanter",
        minutes: 9
    }, 
];

function start() {

}

