function start() {
    var a = 1;
    var b = 2;
    
    var smaller = min(a, b);
    var larger = max(a, b);
}

// return the smaller of two numbers
function min(first, second) {
    
}

// return the larger of two numbers
function max(first, second) {
    
}
