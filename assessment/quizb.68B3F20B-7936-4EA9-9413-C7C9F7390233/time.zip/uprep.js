function start() {
    var time = {
        hours: 0,
        minutes: 1,
        seconds: 2
    };
    
    var longTime = formatTimeLong(time);
    var shortTime = formatTimeShort(time);
}

function formatTimeLong(time) {
    
}

function formatTimeShort(time) {
    
}