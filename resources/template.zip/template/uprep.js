function drawSomething(context) {    
}

function start() {
    var canvas = document.getElementById("mainCanvas");
    var context = canvas.getContext("2d");
    drawSomething(context);
}
